THIS FILE IS IN THE PUBLIC DOMAIN.  DISTRIBUTE FREELY.


The Complete Moby(tm) Shakespeare: CONTENTS
-------------------------------------------
(In approximate chronological order of composition within each group.)


Histories
---------
2 Henry VI
3 Henry VI
1 Henry VI
Richard III
Venus and Adonis
The Rape of Lucrece
Richard II
King John
1 Henry IV
2 Henry IV
Henry V
Sonnets and 'A Lover's Complaint'
Various Poems
Henry VIII

Comedies
--------
The Two Gentlemen of Verona
The Taming of the Shrew
The Comedy of Errors
Love's Labour's Lost
A Midsummer Night's Dream
The Merchant of Venice
The Merry Wives of Windsor
Much Ado About Nothing
As You Like It
Twelfth Night
Troilus and Cressida
Measure for Measure
All's Well That Ends Well
Pericles Prince of Tyre
The Winter's Tale
Cymbeline
The Tempest

Tragedies
---------
Titus Andronicus
Romeo and Juliet
Julius Caesar
Hamlet
Othello
Timon of Athens
King Lear
Macbeth
Antony and Cleopatra
Coriolanus

Glossary
--------
